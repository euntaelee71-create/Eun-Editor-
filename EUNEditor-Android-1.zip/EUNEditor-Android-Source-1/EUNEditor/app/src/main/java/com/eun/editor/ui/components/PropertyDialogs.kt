package com.eun.editor.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.eun.editor.model.VideoFilter

@Composable
fun SpeedDialog(
    initialSpeed: Float,
    onDismiss: () -> Unit,
    onApply: (Float) -> Unit
) {
    var speed by remember { mutableFloatStateOf(initialSpeed) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Playback Speed (\${String.format("%.1fx", speed)})") },
        text = {
            Column {
                Slider(
                    value = speed,
                    onValueChange = { speed = it },
                    valueRange = 0.25f..3.0f,
                    steps = 11
                )
            }
        },
        confirmButton = {
            Button(onClick = { onApply(speed) }) {
                Text("Apply")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun FilterDialog(
    currentFilter: VideoFilter,
    onDismiss: () -> Unit,
    onApply: (VideoFilter) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Color Filter") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                VideoFilter.entries.forEach { filter ->
                    val isSelected = filter == currentFilter
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (isSelected) Color(0xFF333333) else Color.Transparent,
                                RoundedCornerShape(4.dp)
                            )
                            .clickable { onApply(filter) }
                            .padding(12.dp)
                    ) {
                        Text(
                            text = filter.name,
                            color = if (isSelected) Color(0xFF007AFF) else Color.White
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun TextOverlayDialog(
    onDismiss: () -> Unit,
    onApply: (String) -> Unit
) {
    var textValue by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Text Overlay") },
        text = {
            OutlinedTextField(
                value = textValue,
                onValueChange = { textValue = it },
                label = { Text("Text content") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (textValue.isNotBlank()) onApply(textValue)
                }
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
