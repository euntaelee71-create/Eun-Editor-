package com.eun.editor.command

import com.eun.editor.model.EditorProject

interface EditorCommand {
    fun execute(current: EditorProject): EditorProject
    fun undo(current: EditorProject): EditorProject
}

class ProjectCommandHistory {
    private val undoStack = ArrayDeque<EditorCommand>()
    private val redoStack = ArrayDeque<EditorCommand>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun executeCommand(command: EditorCommand, currentProject: EditorProject): EditorProject {
        val updated = command.execute(currentProject)
        undoStack.addLast(command)
        redoStack.clear()
        if (undoStack.size > 25) {
            undoStack.removeFirst()
        }
        return updated
    }

    fun undo(currentProject: EditorProject): EditorProject? {
        if (undoStack.isEmpty()) return null
        val command = undoStack.removeLast()
        val undoneState = command.undo(currentProject)
        redoStack.addLast(command)
        return undoneState
    }

    fun redo(currentProject: EditorProject): EditorProject? {
        if (redoStack.isEmpty()) return null
        val command = redoStack.removeLast()
        val redoneState = command.execute(currentProject)
        undoStack.addLast(command)
        return redoneState
    }
}

class SetProjectCommand(
    private val previousState: EditorProject,
    private val newState: EditorProject
) : EditorCommand {
    override fun execute(current: EditorProject): EditorProject = newState
    override fun undo(current: EditorProject): EditorProject = previousState
}
