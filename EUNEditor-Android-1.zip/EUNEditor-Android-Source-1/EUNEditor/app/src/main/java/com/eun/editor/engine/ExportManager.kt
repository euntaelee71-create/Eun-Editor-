package com.eun.editor.engine

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.TransformationRequest
import androidx.media3.transformer.Transformer
import com.eun.editor.model.EditorProject
import com.eun.editor.model.MediaType
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.io.File

sealed interface ExportStatus {
    data class Progress(val percentage: Int) : ExportStatus
    data class Success(val file: File) : ExportStatus
    data class Failure(val throwable: Throwable) : ExportStatus
}

@OptIn(UnstableApi::class)
class ExportManager(private val context: Context) {

    fun exportProject(project: EditorProject): Flow<ExportStatus> = callbackFlow {
        if (project.clips.isEmpty()) {
            trySend(ExportStatus.Failure(IllegalStateException("No clips available to export.")))
            close()
            return@callbackFlow
        }

        val exportDir = File(context.filesDir, "exports").apply { if (!exists()) mkdirs() }
        val outputFile = File(exportDir, "EUN_${System.currentTimeMillis()}.mp4")

        val sequences = mutableListOf<EditedMediaItemSequence>()
        val editedVideoClips = mutableListOf<EditedMediaItem>()

        for (clip in project.clips) {
            val isImage = clip.mediaType == MediaType.IMAGE
            val mediaItemBuilder = MediaItem.Builder().setUri(clip.uri)

            if (isImage) {
                mediaItemBuilder.setImageDurationMs(clip.durationMs)
            } else {
                val clippingConfig = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(clip.startTrimMs)
                    .setEndPositionMs(clip.endTrimMs)
                    .build()
                mediaItemBuilder.setClippingConfiguration(clippingConfig)
            }

            val mediaItem = mediaItemBuilder.build()

            val clipEffects = mutableListOf<androidx.media3.common.Effect>()
            Media3EffectsFactory.createFilterEffect(clip.filter)?.let { clipEffects.add(it) }

            val audioProcessors = mutableListOf<androidx.media3.common.audio.AudioProcessor>()
            if (clip.speed != 1.0f) {
                val sonic = SonicAudioProcessor().apply {
                    setSpeed(clip.speed)
                }
                audioProcessors.add(sonic)
            }

            val itemEffects = Effects(audioProcessors, clipEffects)
            val editedMediaItemBuilder = EditedMediaItem.Builder(mediaItem).setEffects(itemEffects)

            if (isImage) {
                editedMediaItemBuilder.setFrameRate(30)
            } else {
                editedMediaItemBuilder.setDurationUs(clip.durationMs * 1000L)
            }

            editedVideoClips.add(editedMediaItemBuilder.build())
        }

        sequences.add(EditedMediaItemSequence(editedVideoClips))

        if (project.audioTracks.isNotEmpty()) {
            val editedAudioItems = mutableListOf<EditedMediaItem>()
            for (audio in project.audioTracks) {
                val audioMediaItem = MediaItem.Builder().setUri(audio.uri).build()
                val editedAudioItem = EditedMediaItem.Builder(audioMediaItem).setRemoveVideo(true).build()
                editedAudioItems.add(editedAudioItem)
            }
            sequences.add(EditedMediaItemSequence(editedAudioItems))
        }

        val compositionBuilder = Composition.Builder(sequences)
        Media3EffectsFactory.createTextOverlayEffects(project.textOverlays)?.let {
            compositionBuilder.setEffects(Effects(emptyList(), listOf(it)))
        }
        val composition = compositionBuilder.build()

        val request = TransformationRequest.Builder()
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .build()

        val progressHolder = ProgressHolder()
        var currentTransformer: Transformer? = null

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                trySend(ExportStatus.Progress(100))
                trySend(ExportStatus.Success(outputFile))
                close()
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                trySend(ExportStatus.Failure(exportException))
                close()
            }
        }

        val transformer = Transformer.Builder(context)
            .setTransformationRequest(request)
            .setEncoderFactory(
                DefaultEncoderFactory.Builder(context)
                    .setEnableFallback(true)
                    .build()
            )
            .addListener(listener)
            .build()

        currentTransformer = transformer

        try {
            transformer.start(composition, outputFile.absolutePath)
        } catch (e: Exception) {
            trySend(ExportStatus.Failure(e))
            close()
        }

        val timer = java.util.Timer()
        timer.scheduleAtFixedRate(object : java.util.TimerTask() {
            override fun run() {
                currentTransformer?.let {
                    val progressState = it.getProgress(progressHolder)
                    if (progressState == Transformer.PROGRESS_STATE_AVAILABLE) {
                        trySend(ExportStatus.Progress(progressHolder.progress))
                    }
                }
            }
        }, 200L, 200L)

        awaitClose {
            timer.cancel()
            currentTransformer?.cancel()
        }
    }
}
