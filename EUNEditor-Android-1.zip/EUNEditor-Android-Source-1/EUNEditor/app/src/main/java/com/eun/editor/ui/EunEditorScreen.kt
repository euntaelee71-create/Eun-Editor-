package com.eun.editor.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import com.eun.editor.model.VideoFilter
import com.eun.editor.ui.components.ControlsBar
import com.eun.editor.ui.components.FilterDialog
import com.eun.editor.ui.components.PlayerPreview
import com.eun.editor.ui.components.SpeedDialog
import com.eun.editor.ui.components.TextOverlayDialog
import com.eun.editor.ui.components.TimelineView
import com.eun.editor.viewmodel.EditorViewModel

@Composable
fun EunEditorScreen(viewModel: EditorViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var showSpeedDialog by remember { mutableStateOf(false) }
    var showFilterDialog by remember { mutableStateOf(false) }
    var showTextDialog by remember { mutableStateOf(false) }

    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: SecurityException) {
                }
            }
            viewModel.addMedia(uris, isVideo = true)
        }
    }

    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            viewModel.addAudioTrack(it, "Custom Audio Track")
        }
    }

    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let {
            snackbarHostState.showSnackbar("Error: \$it")
            viewModel.clearExportResult()
        }
    }

    LaunchedEffect(uiState.exportedFile) {
        uiState.exportedFile?.let { file ->
            val uri = FileProvider.getUriForFile(context, "\${context.packageName}.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share Exported Video"))
            viewModel.clearExportResult()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color(0xFF121212)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            PlayerPreview(
                player = viewModel.player,
                activeTextOverlays = uiState.project.textOverlays.filter {
                    uiState.currentPositionMs in it.startTimeMs..it.endTimeMs
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )

            TimelineView(
                project = uiState.project,
                currentPositionMs = uiState.currentPositionMs,
                selectedClipIndex = uiState.selectedClipIndex,
                onClipSelected = { viewModel.selectClip(it) },
                onSeek = { viewModel.seekToTimeline(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            )

            ControlsBar(
                isPlaying = uiState.isPlaying,
                canUndo = uiState.canUndo,
                canRedo = uiState.canRedo,
                hasSelectedClip = uiState.selectedClipIndex != null,
                onPlayPause = { viewModel.togglePlayPause() },
                onImportMedia = { mediaPickerLauncher.launch(arrayOf("video/*", "image/*")) },
                onSplit = { viewModel.splitClipAtCurrentPosition() },
                onSpeedOpen = { showSpeedDialog = true },
                onFilterOpen = { showFilterDialog = true },
                onTextOpen = { showTextDialog = true },
                onAudioOpen = { audioPickerLauncher.launch(arrayOf("audio/*")) },
                onDelete = { viewModel.deleteSelectedClip() },
                onUndo = { viewModel.undo() },
                onRedo = { viewModel.redo() },
                onExport = { viewModel.exportVideo() }
            )
        }
    }

    if (showSpeedDialog) {
        val currentSpeed = uiState.selectedClipIndex?.let {
            uiState.project.clips.getOrNull(it)?.speed
        } ?: 1.0f
        SpeedDialog(
            initialSpeed = currentSpeed,
            onDismiss = { showSpeedDialog = false },
            onApply = { speed ->
                viewModel.setSpeedForSelectedClip(speed)
                showSpeedDialog = false
            }
        )
    }

    if (showFilterDialog) {
        val currentFilter = uiState.selectedClipIndex?.let {
            uiState.project.clips.getOrNull(it)?.filter
        } ?: VideoFilter.NONE
        FilterDialog(
            currentFilter = currentFilter,
            onDismiss = { showFilterDialog = false },
            onApply = { filter ->
                viewModel.setFilterForSelectedClip(filter)
                showFilterDialog = false
            }
        )
    }

    if (showTextDialog) {
        TextOverlayDialog(
            onDismiss = { showTextDialog = false },
            onApply = { text ->
                viewModel.addTextOverlay(text)
                showTextDialog = false
            }
        )
    }

    uiState.exportProgress?.let { progress ->
        Dialog(onDismissRequest = {}) {
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = Color(0xFF222222),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = Color(0xFF007AFF))
                    Text(
                        text = "Exporting MP4: \$progress%",
                        color = Color.White,
                        modifier = Modifier.padding(top = 16.dp)
                    )
                }
            }
        }
    }
}
