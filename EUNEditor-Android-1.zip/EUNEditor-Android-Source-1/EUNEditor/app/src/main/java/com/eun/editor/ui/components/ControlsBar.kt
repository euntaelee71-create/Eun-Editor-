package com.eun.editor.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Filter
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ControlsBar(
    isPlaying: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    hasSelectedClip: Boolean,
    onPlayPause: () -> Unit,
    onImportMedia: () -> Unit,
    onSplit: () -> Unit,
    onSpeedOpen: () -> Unit,
    onFilterOpen: () -> Unit,
    onTextOpen: () -> Unit,
    onAudioOpen: () -> Unit,
    onDelete: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onExport: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth().background(Color(0xFF181818))) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row {
                IconButton(onClick = onUndo, enabled = canUndo) {
                    Icon(Icons.Default.Undo, contentDescription = "Undo", tint = if (canUndo) Color.White else Color.DarkGray)
                }
                IconButton(onClick = onRedo, enabled = canRedo) {
                    Icon(Icons.Default.Redo, contentDescription = "Redo", tint = if (canRedo) Color.White else Color.DarkGray)
                }
            }

            IconButton(onClick = onPlayPause) {
                Icon(
                    if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }

            IconButton(onClick = onExport) {
                Icon(Icons.Default.Upload, contentDescription = "Export MP4", tint = Color(0xFF00C853))
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolButton(icon = Icons.Default.Add, label = "Import", onClick = onImportMedia)
            ToolButton(icon = Icons.Default.ContentCut, label = "Split", enabled = hasSelectedClip, onClick = onSplit)
            ToolButton(icon = Icons.Default.Speed, label = "Speed", enabled = hasSelectedClip, onClick = onSpeedOpen)
            ToolButton(icon = Icons.Default.Filter, label = "Filters", enabled = hasSelectedClip, onClick = onFilterOpen)
            ToolButton(icon = Icons.Default.TextFields, label = "Text", onClick = onTextOpen)
            ToolButton(icon = Icons.Default.Audiotrack, label = "Audio", onClick = onAudioOpen)
            ToolButton(icon = Icons.Default.Delete, label = "Delete", enabled = hasSelectedClip, onClick = onDelete)
        }
    }
}

@Composable
private fun ToolButton(
    icon: ImageVector,
    label: String,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 4.dp)
    ) {
        IconButton(onClick = onClick, enabled = enabled) {
            Icon(
                icon,
                contentDescription = label,
                tint = if (enabled) Color.White else Color.DimGray
            )
        }
        Text(
            text = label,
            fontSize = 11.sp,
            color = if (enabled) Color.LightGray else Color.DimGray
        )
    }
}
