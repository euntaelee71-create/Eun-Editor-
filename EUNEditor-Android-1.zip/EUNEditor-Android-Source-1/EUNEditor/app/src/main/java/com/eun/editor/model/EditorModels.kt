package com.eun.editor.model

import android.net.Uri
import java.util.UUID

enum class MediaType {
    VIDEO, IMAGE
}

enum class VideoFilter {
    NONE, GRAYSCALE, INVERT, SEPIA, HIGH_CONTRAST
}

data class VideoClip(
    val id: String = UUID.randomUUID().toString(),
    val uri: Uri,
    val mediaType: MediaType = MediaType.VIDEO,
    val originalDurationMs: Long,
    val startTrimMs: Long = 0L,
    val endTrimMs: Long = originalDurationMs,
    val speed: Float = 1.0f,
    val volume: Float = 1.0f,
    val filter: VideoFilter = VideoFilter.NONE
) {
    val durationMs: Long
        get() = ((endTrimMs - startTrimMs) / speed).toLong().coerceAtLeast(100L)
}

data class AudioTrack(
    val id: String = UUID.randomUUID().toString(),
    val uri: Uri,
    val title: String = "Background Audio",
    val startOffsetMs: Long = 0L,
    val durationMs: Long = 0L,
    val volume: Float = 1.0f
)

data class TextOverlay(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val xRatio: Float = 0.5f,
    val yRatio: Float = 0.5f,
    val fontSizeSp: Float = 24f,
    val colorHex: Long = 0xFFFFFFFF
)

data class EditorProject(
    val clips: List<VideoClip> = emptyList(),
    val audioTracks: List<AudioTrack> = emptyList(),
    val textOverlays: List<TextOverlay> = emptyList()
) {
    val totalDurationMs: Long
        get() = clips.sumOf { it.durationMs }

    fun findClipAtTime(timelinePositionMs: Long): Pair<Int, VideoClip>? {
        var accumulated = 0L
        clips.forEachIndexed { index, clip ->
            val clipEnd = accumulated + clip.durationMs
            if (timelinePositionMs in accumulated until clipEnd) {
                return Pair(index, clip)
            }
            accumulated = clipEnd
        }
        return if (clips.isNotEmpty() && timelinePositionMs >= accumulated) {
            Pair(clips.lastIndex, clips.last())
        } else null
    }

    fun getTimelineOffsetForClip(clipIndex: Int): Long {
        var offset = 0L
        for (i in 0 until clipIndex.coerceAtMost(clips.size)) {
            offset += clips[i].durationMs
        }
        return offset
    }
}
