package com.eun.editor.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eun.editor.model.EditorProject
import kotlin.math.roundToInt

private const val PIXELS_PER_SECOND = 40f

@Composable
fun TimelineView(
    project: EditorProject,
    currentPositionMs: Long,
    selectedClipIndex: Int?,
    onClipSelected: (Int) -> Unit,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalWidthDp = ((project.totalDurationMs / 1000f) * PIXELS_PER_SECOND).coerceAtLeast(300f).dp
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .background(Color(0xFF1E1E1E))
            .padding(vertical = 8.dp)
    ) {
        val currentSec = currentPositionMs / 1000f
        val totalSec = project.totalDurationMs / 1000f
        Text(
            text = String.format("%02d:%02.1f / %02d:%02.1f", (currentSec / 60).toInt(), currentSec % 60, (totalSec / 60).toInt(), totalSec % 60),
            color = Color.LightGray,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .horizontalScroll(scrollState)
                .pointerInput(project.totalDurationMs) {
                    detectHorizontalDragGestures { change, _ ->
                        change.consume()
                        val newPosMs = ((change.position.x / PIXELS_PER_SECOND) * 1000f).toLong()
                        onSeek(newPosMs.coerceIn(0L, project.totalDurationMs))
                    }
                }
        ) {
            Column(modifier = Modifier.width(totalWidthDp).fillMaxHeight()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .background(Color(0xFF2A2A2A), RoundedCornerShape(4.dp))
                ) {
                    project.clips.forEachIndexed { index, clip ->
                        val clipWidthDp = ((clip.durationMs / 1000f) * PIXELS_PER_SECOND).coerceAtLeast(20f).dp
                        val isSelected = selectedClipIndex == index
                        Box(
                            modifier = Modifier
                                .width(clipWidthDp)
                                .fillMaxHeight()
                                .padding(horizontal = 1.dp)
                                .background(
                                    if (isSelected) Color(0xFF007AFF) else Color(0xFF424242),
                                    RoundedCornerShape(4.dp)
                                )
                                .border(
                                    width = if (isSelected) 2.dp else 0.dp,
                                    color = if (isSelected) Color.White else Color.Transparent,
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .clickable { onClipSelected(index) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Clip ${index + 1}\n${clip.filter.name}",
                                color = Color.White,
                                fontSize = 10.sp,
                                maxLines = 2
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                        .padding(top = 4.dp)
                        .background(Color(0xFF223322), RoundedCornerShape(2.dp))
                ) {
                    project.audioTracks.forEach { audio ->
                        val audioWidthDp = ((audio.durationMs / 1000f) * PIXELS_PER_SECOND).coerceAtLeast(10f).dp
                        Box(
                            modifier = Modifier
                                .width(audioWidthDp)
                                .fillMaxHeight()
                                .background(Color(0xFF2E7D32), RoundedCornerShape(2.dp)),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = "♫ ${audio.title}",
                                color = Color.White,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(start = 4.dp)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                        .padding(top = 4.dp)
                        .background(Color(0xFF332222), RoundedCornerShape(2.dp))
                ) {
                    project.textOverlays.forEach { overlay ->
                        val duration = (overlay.endTimeMs - overlay.startTimeMs).coerceAtLeast(100L)
                        val textWidthDp = ((duration / 1000f) * PIXELS_PER_SECOND).coerceAtLeast(10f).dp
                        Box(
                            modifier = Modifier
                                .width(textWidthDp)
                                .fillMaxHeight()
                                .background(Color(0xFFD84315), RoundedCornerShape(2.dp)),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = "T: ${overlay.text}",
                                color = Color.White,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(start = 4.dp)
                            )
                        }
                    }
                }
            }

            val playheadOffset = ((currentPositionMs / 1000f) * PIXELS_PER_SECOND)
            Box(
                modifier = Modifier
                    .offset { IntOffset(playheadOffset.roundToInt(), 0) }
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(Color.Red)
            )
        }
    }
}
