package com.eun.editor.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.RgbMatrix
import com.eun.editor.model.TextOverlay
import com.eun.editor.model.VideoFilter
import com.google.common.collect.ImmutableList

@UnstableApi
object Media3EffectsFactory {

    fun createFilterEffect(filter: VideoFilter): androidx.media3.common.Effect? {
        return when (filter) {
            VideoFilter.NONE -> null
            VideoFilter.GRAYSCALE -> RgbFilter.createGrayscaleFilter()
            VideoFilter.INVERT -> RgbFilter.createInvertedFilter()
            VideoFilter.SEPIA -> {
                val sepiaMatrix = floatArrayOf(
                    0.393f, 0.769f, 0.189f, 0f,
                    0.349f, 0.686f, 0.168f, 0f,
                    0.272f, 0.534f, 0.131f, 0f,
                    0f,     0f,     0f,     1f
                )
                RgbMatrix { _, _ -> sepiaMatrix }
            }
            VideoFilter.HIGH_CONTRAST -> {
                val contrastMatrix = floatArrayOf(
                    1.5f, 0f,   0f,   -0.2f,
                    0f,   1.5f, 0f,   -0.2f,
                    0f,   0f,   1.5f, -0.2f,
                    0f,   0f,   0f,    1f
                )
                RgbMatrix { _, _ -> contrastMatrix }
            }
        }
    }

    fun createTextOverlayEffects(overlays: List<TextOverlay>): OverlayEffect? {
        if (overlays.isEmpty()) return null

        val bitmapOverlays = overlays.map { overlay ->
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = overlay.fontSizeSp * 2.5f
                color = overlay.colorHex.toInt()
                isFakeBoldText = true
                setShadowLayer(4f, 2f, 2f, android.graphics.Color.BLACK)
            }
            val textBounds = android.graphics.Rect()
            paint.getTextBounds(overlay.text, 0, overlay.text.length, textBounds)

            val width = (textBounds.width() + 40).coerceAtLeast(100)
            val height = (textBounds.height() + 40).coerceAtLeast(60)

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawText(overlay.text, 20f, height - 20f, paint)

            BitmapOverlay.createStaticBitmapOverlay(bitmap)
        }

        return OverlayEffect(ImmutableList.copyOf(bitmapOverlays))
    }
}
