package com.eun.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.eun.editor.ui.EunEditorScreen
import com.eun.editor.ui.theme.EUNEditorTheme
import com.eun.editor.viewmodel.EditorViewModel

class MainActivity : ComponentActivity() {

    private val editorViewModel: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EUNEditorTheme {
                EunEditorScreen(viewModel = editorViewModel)
            }
        }
    }
}
