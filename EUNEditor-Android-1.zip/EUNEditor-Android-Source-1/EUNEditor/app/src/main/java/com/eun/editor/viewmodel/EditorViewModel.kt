package com.eun.editor.viewmodel

import android.app.Application
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.annotation.OptIn
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.eun.editor.command.ProjectCommandHistory
import com.eun.editor.command.SetProjectCommand
import com.eun.editor.engine.ExportManager
import com.eun.editor.engine.ExportStatus
import com.eun.editor.model.AudioTrack
import com.eun.editor.model.EditorProject
import com.eun.editor.model.MediaType
import com.eun.editor.model.TextOverlay
import com.eun.editor.model.VideoClip
import com.eun.editor.model.VideoFilter
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class EditorUiState(
    val project: EditorProject = EditorProject(),
    val currentPositionMs: Long = 0L,
    val isPlaying: Boolean = false,
    val selectedClipIndex: Int? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val exportProgress: Int? = null,
    val exportedFile: File? = null,
    val errorMessage: String? = null
)

@OptIn(UnstableApi::class)
class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private val commandHistory = ProjectCommandHistory()
    private val exportManager = ExportManager(application)
    val player: ExoPlayer = ExoPlayer.Builder(application).build()

    private var playbackPollingJob: Job? = null

    init {
        setupPlayerListener()
        startPlaybackPolling()
    }

    private fun setupPlayerListener() {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _uiState.update { it.copy(isPlaying = isPlaying) }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    player.pause()
                    seekToTimeline(0L)
                }
            }
        })
    }

    private fun startPlaybackPolling() {
        playbackPollingJob?.cancel()
        playbackPollingJob = viewModelScope.launch {
            while (true) {
                if (player.isPlaying) {
                    val mediaItemIdx = player.currentMediaItemIndex
                    val currentClipPos = player.currentPosition
                    val project = _uiState.value.project
                    val offset = project.getTimelineOffsetForClip(mediaItemIdx)
                    val timelinePos = offset + (currentClipPos * (project.clips.getOrNull(mediaItemIdx)?.speed ?: 1f)).toLong()
                    _uiState.update { it.copy(currentPositionMs = timelinePos.coerceAtMost(project.totalDurationMs)) }
                }
                delay(33L)
            }
        }
    }

    private fun applyProjectUpdate(newProject: EditorProject) {
        val oldProject = _uiState.value.project
        val updated = commandHistory.executeCommand(SetProjectCommand(oldProject, newProject), oldProject)
        syncProjectState(updated)
    }

    private fun syncProjectState(newProject: EditorProject) {
        _uiState.update {
            it.copy(
                project = newProject,
                canUndo = commandHistory.canUndo,
                canRedo = commandHistory.canRedo,
                selectedClipIndex = if (newProject.clips.isEmpty()) null else it.selectedClipIndex?.coerceAtMost(newProject.clips.lastIndex)
            )
        }
        rebuildPlayerPlaylist(newProject)
    }

    private fun rebuildPlayerPlaylist(project: EditorProject) {
        val wasPlaying = player.isPlaying
        val savedPos = _uiState.value.currentPositionMs

        player.clearMediaItems()
        for (clip in project.clips) {
            val clippingConfig = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(clip.startTrimMs)
                .setEndPositionMs(clip.endTrimMs)
                .build()

            val item = MediaItem.Builder()
                .setUri(clip.uri)
                .setClippingConfiguration(clippingConfig)
                .build()
            player.addMediaItem(item)
        }
        player.prepare()
        seekToTimeline(savedPos)
        if (wasPlaying) player.play()
    }

    fun addMedia(uris: List<Uri>, isVideo: Boolean) {
        viewModelScope.launch {
            val newClips = uris.map { uri ->
                val duration = queryDuration(uri, isVideo)
                VideoClip(
                    uri = uri,
                    mediaType = if (isVideo) MediaType.VIDEO else MediaType.IMAGE,
                    originalDurationMs = duration,
                    endTrimMs = duration
                )
            }
            val currentClips = _uiState.value.project.clips.toMutableList()
            currentClips.addAll(newClips)
            applyProjectUpdate(_uiState.value.project.copy(clips = currentClips))
        }
    }

    private fun queryDuration(uri: Uri, isVideo: Boolean): Long {
        if (!isVideo) return 3000L
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(getApplication(), uri)
            val time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            time?.toLong() ?: 3000L
        } catch (e: Exception) {
            3000L
        } finally {
            retriever.release()
        }
    }

    fun selectClip(index: Int?) {
        _uiState.update { it.copy(selectedClipIndex = index) }
    }

    fun togglePlayPause() {
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_ENDED) {
                seekToTimeline(0L)
            }
            player.play()
        }
    }

    fun seekToTimeline(positionMs: Long) {
        val project = _uiState.value.project
        val bounded = positionMs.coerceIn(0L, project.totalDurationMs.coerceAtLeast(1L))
        _uiState.update { it.copy(currentPositionMs = bounded) }

        var accumulated = 0L
        for (i in project.clips.indices) {
            val clipDuration = project.clips[i].durationMs
            if (bounded in accumulated..(accumulated + clipDuration)) {
                val clipRelative = bounded - accumulated
                val clipSeekPos = (clipRelative * project.clips[i].speed).toLong()
                player.seekTo(i, clipSeekPos)
                return
            }
            accumulated += clipDuration
        }
    }

    fun splitClipAtCurrentPosition() {
        val state = _uiState.value
        val currentPos = state.currentPositionMs
        val pair = state.project.findClipAtTime(currentPos) ?: return
        val index = pair.first
        val clip = pair.second

        val clipStartOnTimeline = state.project.getTimelineOffsetForClip(index)
        val splitOffsetWithinClip = ((currentPos - clipStartOnTimeline) * clip.speed).toLong()

        val splitPointMs = clip.startTrimMs + splitOffsetWithinClip
        if (splitPointMs <= clip.startTrimMs + 300L || splitPointMs >= clip.endTrimMs - 300L) {
            return
        }

        val firstHalf = clip.copy(endTrimMs = splitPointMs)
        val secondHalf = clip.copy(startTrimMs = splitPointMs)

        val updated = state.project.clips.toMutableList()
        updated[index] = firstHalf
        updated.add(index + 1, secondHalf)

        applyProjectUpdate(state.project.copy(clips = updated))
    }

    fun trimSelectedClip(newStartMs: Long, newEndMs: Long) {
        val state = _uiState.value
        val index = state.selectedClipIndex ?: return
        val clip = state.project.clips.getOrNull(index) ?: return

        if (newEndMs - newStartMs < 300L) return

        val trimmed = clip.copy(startTrimMs = newStartMs, endTrimMs = newEndMs)
        val updated = state.project.clips.toMutableList()
        updated[index] = trimmed

        applyProjectUpdate(state.project.copy(clips = updated))
    }

    fun setSpeedForSelectedClip(speed: Float) {
        val state = _uiState.value
        val index = state.selectedClipIndex ?: return
        val clip = state.project.clips.getOrNull(index) ?: return

        val updatedClip = clip.copy(speed = speed)
        val updated = state.project.clips.toMutableList()
        updated[index] = updatedClip

        applyProjectUpdate(state.project.copy(clips = updated))
    }

    fun setFilterForSelectedClip(filter: VideoFilter) {
        val state = _uiState.value
        val index = state.selectedClipIndex ?: return
        val clip = state.project.clips.getOrNull(index) ?: return

        val updatedClip = clip.copy(filter = filter)
        val updated = state.project.clips.toMutableList()
        updated[index] = updatedClip

        applyProjectUpdate(state.project.copy(clips = updated))
    }

    fun deleteSelectedClip() {
        val state = _uiState.value
        val index = state.selectedClipIndex ?: return
        if (index !in state.project.clips.indices) return

        val updated = state.project.clips.toMutableList()
        updated.removeAt(index)

        applyProjectUpdate(state.project.copy(clips = updated))
        _uiState.update { it.copy(selectedClipIndex = null) }
    }

    fun addAudioTrack(uri: Uri, title: String) {
        val state = _uiState.value
        val track = AudioTrack(uri = uri, title = title, durationMs = 15000L)
        val updatedAudio = state.project.audioTracks + track
        applyProjectUpdate(state.project.copy(audioTracks = updatedAudio))
    }

    fun addTextOverlay(text: String) {
        val state = _uiState.value
        val start = state.currentPositionMs
        val overlay = TextOverlay(
            text = text,
            startTimeMs = start,
            endTimeMs = (start + 3000L).coerceAtMost(state.project.totalDurationMs.coerceAtLeast(3000L))
        )
        val updatedText = state.project.textOverlays + overlay
        applyProjectUpdate(state.project.copy(textOverlays = updatedText))
    }

    fun undo() {
        val restored = commandHistory.undo(_uiState.value.project)
        if (restored != null) {
            syncProjectState(restored)
        }
    }

    fun redo() {
        val redone = commandHistory.redo(_uiState.value.project)
        if (redone != null) {
            syncProjectState(redone)
        }
    }

    fun exportVideo() {
        viewModelScope.launch {
            _uiState.update { it.copy(exportProgress = 0, errorMessage = null, exportedFile = null) }
            exportManager.exportProject(_uiState.value.project).collect { status ->
                when (status) {
                    is ExportStatus.Progress -> _uiState.update { it.copy(exportProgress = status.percentage) }
                    is ExportStatus.Success -> _uiState.update { it.copy(exportProgress = null, exportedFile = status.file) }
                    is ExportStatus.Failure -> _uiState.update { it.copy(exportProgress = null, errorMessage = status.throwable.localizedMessage) }
                }
            }
        }
    }

    fun clearExportResult() {
        _uiState.update { it.copy(exportedFile = null, errorMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        playbackPollingJob?.cancel()
        player.release()
    }
}
