EUN EDITOR — ANDROID SOURCE PROJECT

This ZIP contains generated Android source, not a precompiled APK.
The current chat runtime does not have the Android SDK/Gradle build environment needed to compile and test an APK locally.

Cloud build included:
1. Upload/extract this project into a GitHub repository.
2. Open the repository's Actions tab.
3. Run “Build EUN Editor APK” (or push to main/master).
4. When the workflow completes successfully, download the “EUN-Editor-debug-APK” artifact.

The workflow compiles a DEBUG APK. It is not a signed Play Store release. The project has not been compiled or tested on a device in this environment; build errors may still need fixing.

Package: com.eun.editor
Minimum Android API: 24
Target Android API: 34
